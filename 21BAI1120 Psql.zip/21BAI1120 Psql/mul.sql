DECLARE
	num int := 5;
	
BEGIN
	/*21BAI1120*/
	FOR i IN 1 .. 10 LOOP 
   	dbms_output.put_line(num*i);
	END LOOP;
	
	
END;
/