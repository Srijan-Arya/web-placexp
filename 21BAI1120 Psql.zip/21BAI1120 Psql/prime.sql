DECLARE
	num int := 17;
	flag int :=0;
	
BEGIN
	 FOR i IN 2 .. (num/2) LOOP 
	 	IF (mod(num,i)=0) THEN 
         		flag:=1;
			EXIT;
		END IF;

	 END LOOP;

	IF (flag = 0) THEN
	      dbms_output.put_line('PRIME');
	ELSE  
	      dbms_output.put_line('Not Prime');
	END IF; 

END;
/
