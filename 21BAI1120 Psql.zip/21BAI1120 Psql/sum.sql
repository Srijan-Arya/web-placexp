DECLARE
	first int := 5;
	second int := 15;

BEGIN
	dbms_output.put_line(first+SECOND);
	
END;
/