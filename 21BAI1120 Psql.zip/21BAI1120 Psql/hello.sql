DECLARE
	num int := 23;
	flag int:=0

BEGIN	 FOR i IN 2 .. num/2 LOOP 
	 IF ( num%i==0 ) THEN 
         dbms_output.put_line('Not Prime' ); 
	 flag=1;
	 END LOOP;

	 IF (flag==0) THEN
 	 dbms.output.put_line('PRIME');
	 
	
	
END;
/
